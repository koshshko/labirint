valid_email = "testtestov.09.02.2022@yandex.ru"
valid_password = "Test.09.02.2022"
project_url = 'https://www.labirint.ru/'
favorites_url = 'https://www.labirint.ru/cabinet/putorder/'
cart_url = 'https://www.labirint.ru/cart/'
compare_url = 'https://www.labirint.ru/compare/'
support_url = 'https://www.labirint.ru/support/'
help_url = 'https://www.labirint.ru/help/'
checkout_page = 'https://www.labirint.ru/basket/checkout/'
discount_code = '2F28-4435-9769'
email = 'test.21.03.2022@test.test'
login = 'Test'
valid_phone = '+79876543210'

social_network = {
    'vk': 'https://vk.com/labirint_ru',
    'vk.deti': 'https://vk.com/labirintdeti',
    'youtube': 'https://www.youtube.com/user/labirintruTV',
    'ok': 'https://ok.ru/labirintru',
    'zen': 'https://zen.yandex.ru/labirintru',
    'telegram': 'https://t.me/labirintru',
    'tiktok': 'https://www.tiktok.com/@labirintru'
}